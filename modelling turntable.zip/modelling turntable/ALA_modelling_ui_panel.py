import bpy
from . import ALA_modelling_turntable
from bpy_extras.io_utils import ImportHelper
from bpy.props import (StringProperty, EnumProperty, CollectionProperty, FloatProperty, BoolProperty, IntProperty)

class ALA_PG_turntableoptions(bpy.types.PropertyGroup):
    autoplayttbool : BoolProperty(name="Autoplay rendered turntable", description="Autoplays rendered turntable", default=False)

class ALAModellingToolkit(bpy.types.Panel):
    bl_idname = "ALA_PT_Modelling_Toolkit"
    bl_label = "ALA Modelling Toolkit"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "ALA Modelling"
    bl_options = {"DEFAULT_CLOSED"}
    bl_context_mode = "OBJECT"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        layout.label(text="Modelling toolkit panel")
        
class ALA_PT_modelling_turntable(ALAModellingToolkit, bpy.types.Panel):
    bl_idname = "ALA_PT_animation_turntable"
    bl_space_type = "VIEW_3D"
    bl_description = "Renders a modelling Turntable"
    bl_label = "Modelling Turntable"
    bl_region_type = "UI"
    bl_category = "ALA Modelling"
    bl_options = {"DEFAULT_CLOSED"}
    bl_context_mode = "OBJECT"

    def draw(self, context):
        scene = context.scene
        layout = self.layout
        layout.label(text="Automatically render asset in a turntable")
        layout.label(text="Select asset to create a standard turntable")
        col = layout.column(align=True)
        col.prop(scene, 'autoplayttbool', text="Autoplay after render")
        row = layout.row()
        row.operator(ALA_OT_ModellingTurntable.bl_idname, text="Auto Create Turntable Render")

class ALA_PT_adjustable_modelling_turntable(ALAModellingToolkit, bpy.types.Panel):
    bl_idname = "ALA_PT_adjustable_animation_turntable"
    bl_space_type = "VIEW_3D"
    bl_description = "Renders a modelling Turntable with personal adjustments"
    bl_label = "Adjustable Modelling Turntable"
    bl_region_type = "UI"
    bl_category = "ALA Modelling"
    bl_options = {"DEFAULT_CLOSED"}
    bl_context_mode = "OBJECT"

    def draw(self, context):
        scene = context.scene
        layout = self.layout
        layout.label(text="Adjust the turntable to personal likings")
        layout.label(text="Select asset and adjust turntable settings")
        col = layout.column(align=True)
        col.prop(scene, 'autoplayttbool', text="Autoplay after render")
        col.operator(ALA_OT_rig.bl_idname, text="Custom turntable")
        row = layout.row()
        row.operator(ALA_OT_render.bl_idname, text="Render")


class ALA_OT_ModellingTurntable(bpy.types.Operator, ImportHelper):
    bl_idname = "ala_modelling_toolkit.ala_modelling_turntable"
    bl_description = "Renders an mp4 with the asset in a 360 turntable"
    bl_label = "Create Turntable"
    def execute(self, context):
        ALA_modelling_turntable.run_turntable(self,self.filepath)
        return {'FINISHED'}

class ALA_OT_render(bpy.types.Operator):
    bl_idname = "ala_modelling_toolkit.ala_render"
    bl_description = "Renders after user adjustments"
    bl_label = "Render"
    def execute(self, context):
        ALA_modelling_turntable.render_model(camera_empty, file_path)
        return {'FINISHED'}

class ALA_OT_rig(bpy.types.Operator):
    bl_idname = "ala_modelling_toolkit.ala_rig"
    bl_description = "Creates the turntable rig in the scene that can be adjusted"
    bl_label = "Create turntable rig"
    def execute(self, context):
        ALA_modelling_turntable.custom_rig()
        return {'FINISHED'}

class ALA_OT_autoplaytt(bpy.types.Operator):
    bl_idname = "ala_modelling_toolkit.ala_autoplaytt"
    bl_description = "Autoplay after render"
    bl_label = "Autoplay after render"
    def execute(self, context):
        # ALA_modelling_turntable.autoplaytt()
        return {'FINISHED'}

classes = (
    ALA_PG_turntableoptions,
    ALAModellingToolkit,
    ALA_PT_modelling_turntable,
    ALA_PT_adjustable_modelling_turntable,
    ALA_OT_ModellingTurntable,
    ALA_OT_render,
    ALA_OT_rig,
    ALA_OT_autoplaytt

)

def register():
    bpy.types.Scene.autoplayttbool = BoolProperty(name="autoplayttbool")
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    del bpy.types.Scene.autoplayttbool
    for cls in classes:
        bpy.utils.unregister_class(cls)
if __name__ == "__main__":
    register()
    
     