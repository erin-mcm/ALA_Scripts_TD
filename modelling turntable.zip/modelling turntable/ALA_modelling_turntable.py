import bpy
import datetime
import functools
import math
import pathlib
from mathutils import Vector
import sys
import os
import addon_utils
from bpy.app.handlers import persistent
import pathlib
import logging

def make_active(obj):
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    #this will be used later to delete the sphere
def active_object():
    return bpy.context.active_object

#create floor
def create_floor(world_bounds):
    #bpy.ops.mesh.primitive_plane_add(enter_editmode=False, align='WORLD', location=(0, 0, object_world_bounds[1][2]-0.01))
    object_center = Vector(((world_bounds[0][0]+world_bounds[1][0])/2.0,(world_bounds[0][1]+world_bounds[1][1])/2.0,(world_bounds[0][2]+world_bounds[1][2])/2.0))
    bpy.ops.mesh.primitive_uv_sphere_add(location=object_center)
    floor = active_object()
    floor.scale[0] = 10000
    floor.scale[1] = 10000
    floor.scale[2] = 10000
    material = bpy.data.materials.new(name="floor_material")
    material.diffuse_color = (0.1, 0.1, 0, 1.0)
    material.specular_intensity = 0
    floor.data.materials.append(material)
    
#figure out the max and min coords of selected
def get_max_and_min_coords(objects):
    total_world_bounds = []
    for obj in objects:
        vertices = obj.data.vertices
        obj_world_bounds = []
        
        for v in vertices:
            obj_world_bounds.append(obj.matrix_world @ v.co)
        
        total_world_bounds.append(obj_world_bounds)
    
    max_bounds = []
    min_bounds = []
    
    for bounds in total_world_bounds:
        max_bounds.append(get_max_vector(bounds))
        min_bounds.append(get_min_vector(bounds))
    
    vector_max = get_max_vector(max_bounds)
    vector_min = get_min_vector(min_bounds)
    
    return (vector_max, vector_min)

def get_max_vector(world_coords):
    vector_max = Vector((max(world_coords[i][0] for i in range(len(world_coords))), max(world_coords[i][1] for i in range(len(world_coords))), max(world_coords[i][2] for i in range(len(world_coords)))))
    return vector_max

def get_min_vector(world_coords):
    vector_min = Vector((min(world_coords[i][0] for i in range(len(world_coords))), min(world_coords[i][1] for i in range(len(world_coords))), min(world_coords[i][2] for i in range(len(world_coords)))))
    return vector_min

def create_cameracontrol(world_bounds, camera_parent):
    #create empty at object center
    #create camera
    cam = bpy.ops.object.camera_add()
    cam = active_object()    
    #parent camera to move with empty
    bpy.ops.object.parent_set(type='OBJECT')
    cam.parent = camera_parent
    #constrain camera to look at object
    longest_side = (world_bounds[0] - world_bounds[1]).length
    cam.location = (0,-1,0)
    bpy.ops.object.constraint_add(type="TRACK_TO")
    cam.constraints["Track To"].target = camera_parent
    cam.constraints["Track To"].use_target_z = True
    #create sphere to ensure the whole object is in the frame and can be views
    sphere = bpy.ops.mesh.primitive_uv_sphere_add()
    sphere = active_object()
    sphere.dimensions = (longest_side,longest_side,longest_side)
    sphere.location = camera_parent.location
    #fit the view of the camera with the model
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            with bpy.context.temp_override(area=area, region=[x for x in area.regions if x.type == 'WINDOW'][0]):
                make_active(cam)
                bpy.ops.view3d.object_as_camera()
                make_active(sphere)
                bpy.ops.view3d.camera_to_view_selected()
                #remove sphere
                bpy.ops.object.delete()
            break
    make_active(camera_parent)

def light_controls(camera_empty):
    make_active(camera_empty)
    #add tri lighting to make it look spicy
    bpy.ops.preferences.addon_enable(module="lighting_tri_lights")
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            with bpy.context.temp_override(area=area, region=[x for x in area.regions if x.type == 'WINDOW'][0]):
                bpy.ops.object.trilighting()
            break
    #change the settings of the lights
    tlights = ["TriLamp-Key", "TriLamp-Fill", "TriLamp-Back"]
    bpy.ops.object.empty_add(type="PLAIN_AXES", location=camera_empty.location)
    lights_parent = active_object()
    for name in tlights:
        l = bpy.data.lights[name]
        o = bpy.data.objects[name]
        make_active(o)
        l.energy = 2
        l.type = "SUN"
        bpy.ops.object.parent_set(type='OBJECT')
        o.parent = lights_parent
    return lights_parent

def animate_rotation(model_parent, camera_parent, lights_parent):
    bpy.data.scenes["Scene"].frame_start = 1
    bpy.data.scenes["Scene"].frame_end = 300
    # insert keyframe at frame one
    start_frame = 1
    #frame inserts
    camera_parent.keyframe_insert("rotation_euler", frame=start_frame)
    #rotation
    degrees = 360
    # convert degrees to radians to caculate circle animation
    radians = math.radians(degrees)
    camera_parent.rotation_euler.z = radians
    #insert at end frame
    end_frame = 100
    #frame inserts
    camera_parent.keyframe_insert("rotation_euler", frame=end_frame)
    
    # insert keyframe at frame one
    start_frame = 101
    #frame inserts
    camera_parent.keyframe_insert("rotation_euler", frame=start_frame)
    #rotation
    # convert degrees to radians to caculate circle animation
    camera_parent.rotation_euler.x = radians
    #insert at end frame
    end_frame = 200
    #frame inserts
    camera_parent.keyframe_insert("rotation_euler", frame=end_frame)
    
    start_frame = 201
    #frame inserts
    lights_parent.rotation_euler.z = 0
    lights_parent.keyframe_insert("rotation_euler", frame=start_frame)
    #rotation
    # convert degrees to radians to caculate circle animation
    lights_parent.rotation_euler.z = radians
    #insert at end frame
    end_frame = 300
    #frame inserts
    lights_parent.keyframe_insert("rotation_euler", frame=end_frame)

def custom_rig():
    selected_objects = bpy.context.selected_objects
    model_world_bounds = get_max_and_min_coords(selected_objects)
    object_center = Vector(((model_world_bounds[0][0]+model_world_bounds[1][0])/2.0,(model_world_bounds[0][1]+model_world_bounds[1][1])/2.0,(model_world_bounds[0][2]+model_world_bounds[1][2])/2.0))
    model_empty = bpy.ops.object.empty_add(type="PLAIN_AXES", location=object_center)
    model_empty = active_object()
    object_center = Vector(((model_world_bounds[0][0]+model_world_bounds[1][0])/2.0,(model_world_bounds[0][1]+model_world_bounds[1][1])/2.0,(model_world_bounds[0][2]+model_world_bounds[1][2])/2.0))
    camera_empty = bpy.ops.object.empty_add(type="PLAIN_AXES", location=(object_center))
    camera_empty = active_object()
    create_cameracontrol(model_world_bounds, camera_empty)
    lights_parent = light_controls(camera_empty)
    animate_rotation(model_empty, camera_empty, lights_parent)
    rig_empty = bpy.ops.object.empty_add(type="PLAIN_AXES", location=(object_center))
    rig_empty = active_object()
    lights_parent.parent = rig_empty
    camera_empty.parent = rig_empty
    model_empty.parent = rig_empty
    lights_parent.name = "Rig Lights Parent"
    model_empty.name = "Rig Model Parent"
    camera_empty.name = "Rig Camera Parent"
    rig_empty.name = "Modelling Turntable Rig"

def render_model(camera_empty, file_path):
    time_stamp = datetime.datetime.now().strftime("%H-%M-%S")
    # output_folder_path = file_path
    # path = str(output_folder_path + f'modelling_turntable_{time_stamp}.mp4')
    bpy.context.scene.render.filepath = file_path.format()
    bpy.context.scene.render.image_settings.file_format = "FFMPEG"
    bpy.context.scene.render.ffmpeg.format = "MPEG4"
    bpy.context.scene.render.engine = "BLENDER_EEVEE"
    bpy.ops.render.render(animation=True)
    if(bpy.context.scene.autoplayttbool == True):
        bpy.ops.render.play_rendered_anim()
    print("autoplay done")

def run_turntable(self, filepath):
    print("check save")
    if bpy.data.is_dirty:
        self.report({'INFO'}, "Save your file before continuing")
        return
    else:
        print("File OK!")

    try:
        print("saving")
        bpy.ops.wm.save_mainfile()

        selected_objects = bpy.context.selected_objects

        for m in selected_objects:
            if m == 'FONT':
                print(m)
                make_active(m)
                bpy.ops.object.convert(target='MESH')
                bpy.ops.object.select_all(action='DESELECT')
                continue
            if m.type !='MESH':
                print(m)
                m.select_set(False)
        bpy.ops.object.select_all(action='INVERT')
        bpy.ops.object.delete()

        model_world_bounds = get_max_and_min_coords(selected_objects)
        
        #create_floor(model_world_bounds)
        object_center = Vector(((model_world_bounds[0][0]+model_world_bounds[1][0])/2.0,(model_world_bounds[0][1]+model_world_bounds[1][1])/2.0,(model_world_bounds[0][2]+model_world_bounds[1][2])/2.0))
        model_empty = bpy.ops.object.empty_add(type="PLAIN_AXES", location=object_center)
        model_empty = active_object()

        object_center = Vector(((model_world_bounds[0][0]+model_world_bounds[1][0])/2.0,(model_world_bounds[0][1]+model_world_bounds[1][1])/2.0,(model_world_bounds[0][2]+model_world_bounds[1][2])/2.0))
        camera_empty = bpy.ops.object.empty_add(type="PLAIN_AXES", location=(object_center))
        camera_empty = active_object()
        for obj in selected_objects:
            if obj.parent == None:
                obj.parent = model_empty
                obj.location = (obj.location - object_center)
        print("creating camera control")
        create_cameracontrol(model_world_bounds, camera_empty)
        print("creating animation")
        lights_parent = light_controls(camera_empty)
        animate_rotation(model_empty, camera_empty, lights_parent)
        print("rendering")
        rig_empty = bpy.ops.object.empty_add(type="PLAIN_AXES", location=(object_center))
        rig_empty = active_object()
        lights_parent.parent = rig_empty
        camera_empty.parent = rig_empty
        model_empty.parent = rig_empty
        lights_parent.name = "Rig Lights Parent"
        model_empty.name = "Rig Model Parent"
        camera_empty.name = "Rig Camera Parent"
        rig_empty.name = "Modelling Turntable Rig"
        render_model(camera_empty, filepath)
        print("done")
        self.report({'INFO'}, "Turntable finished")
        print("autoplay done")
    except Exception as e:
        self.report({'ERROR'}, "Error running turntable: " + str(e))
    finally:
        bpy.ops.wm.revert_mainfile()
        print("Finished")
    
# if __name__ == "__main__":
#     main()
    
